import java.awt.*;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
public class InfPanel extends JPanel
{
    private JLabel scrlTxt;
    private String in;
    public InfPanel ()
    {
        super ();
        setLayout(new GridLayout());
        setBackground(Color.red);
        addScrollText();
        getNews2();
        
    }
     
    
    public InfPanel(String info){
        in = info;
        
    }
    
    public void addScrollText(){
        
        scrlTxt = new JLabel("Headlines: ");
        scrlTxt.setFont(new Font("Serif", Font.BOLD, 38));
        scrlTxt.setForeground(Color.white);
        add(scrlTxt);
        
        
    }
     private void getNews2() {
        JLabel news = new JLabel("");
        news.setFont(new Font("Serif", Font.BOLD, 20));
         news.setHorizontalAlignment(SwingConstants.LEFT);
        add(news);
        
        JSONParser parser = new JSONParser();
        try {
            JSONObject json = (JSONObject) parser.parse(getNewsData());
            JSONArray articles = (JSONArray) json.get("articles");
            JSONObject article = (JSONObject) articles.get(0);
            
            news.setText("<html>"+(String)article.get("title")+"</html>");
            
            
            news.setFont(new Font("Arial", Font.BOLD, 18));
            news.setForeground(Color.WHITE);
           
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private String getNewsData() {
       
        
        String response = "";
        try {
            URL url = new URL("https://newsapi.org/v2/top-headlines?country=us&apiKey=74e0caef3f69426e9228da0337cfbb18");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // read the response and obtain string value of JSON data
            InputStream in = new BufferedInputStream(connection.getInputStream());
            response = convertJSONtoString(in);
        }
        catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
        return response;
    }
    
    private String convertJSONtoString(InputStream is)
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;

        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }      
        return sb.toString();
    }
    }
    
    

 