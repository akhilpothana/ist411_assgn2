/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author equay
 */
public class Location{
    
    private String state;
    private String city;
    private String county;
    private int locationZip;
    
    
    
    public Location(String userState, String userCity, String userCounty, int userLocationZip){
        state = userState;
        city = userCity;
        county = userCounty;
        locationZip = userLocationZip;
        
    }

   
    public String getUserLocation(){
        
        return state + " " + city + " " + county + "" +locationZip;
        
    }
    
    public String setUserLocation(){
        
        
        return state + " " + city +" "+county;
                
    }
    
    //could add a method that creates a cluster below
}
