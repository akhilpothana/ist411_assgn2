/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author equay
 */
public class Profile {
    
    private String fName;
    private String lName;
    private String gender;
    private String email;
    private int age;
    private int zip;
    private int phone;
    private String info;
    private String auth;
    private String access;
    
    Profile(String newFirstName, String newLastName, String newGender, 
            String newEmail, int newAge,  int newZipCode, int newPhoneNum){
        
        fName = newFirstName;
        lName = newLastName;
        gender = newGender;
        email = newEmail;
        age = newAge;
        zip = newZipCode;
        phone = newPhoneNum;
        
    }

    
    
    public String getRegistrationInfo(){
        return info;
        
    }
    
    public String authenticateUser(){
        return auth;
    }
    
    public String grantAccess(){
        return access;
    }
}
