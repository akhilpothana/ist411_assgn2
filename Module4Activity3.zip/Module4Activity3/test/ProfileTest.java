/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author equay
 */
public class ProfileTest {
    
    public ProfileTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getRegistrationInfo method, of class Profile.
     */
    @Test
    public void testGetRegistrationInfo() {
        System.out.println("getRegistrationInfo");
        Profile instance = new Profile("Love","Newman","F","lnewman@ist311.com",27,00000,00000000);
        instance.getRegistrationInfo();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of authenticateUser method, of class Profile.
     */
    @Test
    public void testAuthenticateUser() {
        System.out.println("authenticateUser");
        Profile instance = new Profile("Nat","Favor","M","nfavor@ist311.com",27,00000,00000000);
        instance.authenticateUser();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of grantAccess method, of class Profile.
     */
    @Test
    public void testGrantAccess() {
        System.out.println("grantAccess");
        Profile instance = new Profile("Lexis","Hogan","M","lhogan@ist311.com",27,00000,00000000);
        instance.grantAccess();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
