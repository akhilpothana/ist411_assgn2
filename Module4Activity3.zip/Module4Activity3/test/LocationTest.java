/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author equay
 */
public class LocationTest {
    
    public LocationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getUserLocation method, of class Location.
     */
    @Test
    public void testGetUserLocation() {
        System.out.println("getUserLocation");
        Location instance = new Location("Highland","spring city","hickory", 55555);
        instance.getUserLocation();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of setUserLocation method, of class Location.
     */
    @Test
    public void testSetUserLocation() {
        System.out.println("setUserLocation");
        Location instance = new Location("Highland","spring city","hickory", 55555);
        instance.setUserLocation();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
